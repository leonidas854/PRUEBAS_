from django.apps import AppConfig


class ReynasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reynas'
